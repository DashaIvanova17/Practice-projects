﻿using System;
using System.Collections.Generic;

// Класс банковского счета
public class BankAccount
{
    private decimal _balance;

    public BankAccount(decimal initialBalance)
    {
        _balance = initialBalance;
    }

    // Пополнение счета
    public void Deposit(decimal amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Сумма для пополнения должна быть положительной");
            return;
        }
        _balance += amount;
        Console.WriteLine($"Счет пополнен на {amount}. Новый баланс: {_balance}");
    }

    // Снятие средств
    public void Withdraw(decimal amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Сумма для снятия должна быть положительной");
            return;
        }
        if (amount > _balance)
        {
            Console.WriteLine("Недостаточно средств на счете");
            return;
        }
        _balance -= amount;
        Console.WriteLine($"Со счета снято {amount}. Новый баланс: {_balance}");
    }

    // Получение баланса
    public decimal GetBalance()
    {
        return _balance;
    }
}

// Класс клиента банка
public class Client
{
    private string _name;
    private List<BankAccount> _accounts;

    public Client(string name)
    {
        _name = name;
        _accounts = new List<BankAccount>();
    }

    public string Name => _name;

    public void AddAccount(BankAccount account)
    {
        _accounts.Add(account);
    }

    public List<BankAccount> GetAccounts()
    {
        return _accounts;
    }
}

// Класс банка
public class Bank
{
    private List<Client> _clients;

    public Bank()
    {
        _clients = new List<Client>();
    }

    public void AddClient(Client client)
    {
        _clients.Add(client);
    }

    public List<Client> GetClients()
    {
        return _clients;
    }
}

// Основная программа
class Program
{
    static void Main(string[] args)
    {
        Bank bank = new Bank();

        // Создаем клиентов и счета
        Client client1 = new Client("Иван Иванов");
        client1.AddAccount(new BankAccount(1000));
        client1.AddAccount(new BankAccount(500));

        Client client2 = new Client("Петр Петров");
        client2.AddAccount(new BankAccount(2000));

        bank.AddClient(client1);
        bank.AddClient(client2);

        // Циклическое меню
        int menuOption;
        do
        {
            Console.WriteLine("\n--- Банковская система ---");
            Console.WriteLine("1. Показать всех клиентов");
            Console.WriteLine("2. Управление счетами клиента");
            Console.WriteLine("3. Выход");
            Console.Write("Выберите опцию: ");

            if (!int.TryParse(Console.ReadLine(), out menuOption))
            {
                Console.WriteLine("Некорректный ввод. Попробуйте снова.");
                continue;
            }

            switch (menuOption)
            {
                case 1:
                    ShowAllClients(bank);
                    break;
                case 2:
                    ManageClientAccounts(bank);
                    break;
                case 3:
                    Console.WriteLine("Выход из программы...");
                    break;
                default:
                    Console.WriteLine("Неизвестная опция. Попробуйте снова.");
                    break;
            }

        } while (menuOption != 3);
    }

    static void ShowAllClients(Bank bank)
    {
        Console.WriteLine("\nСписок клиентов:");
        foreach (var client in bank.GetClients())
        {
            Console.WriteLine($"- {client.Name}");
        }
    }

    static void ManageClientAccounts(Bank bank)
    {
        Console.Write("\nВведите имя клиента: ");
        string clientName = Console.ReadLine();

        Client foundClient = bank.GetClients().Find(c => c.Name == clientName);
        if (foundClient == null)
        {
            Console.WriteLine("Клиент не найден.");
            return;
        }

        Console.WriteLine($"\nУправление счетами клиента {foundClient.Name}");
        var accounts = foundClient.GetAccounts();

        for (int i = 0; i < accounts.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Счет с балансом: {accounts[i].GetBalance()}");
        }

        Console.Write("Выберите счет (1-" + accounts.Count + "): ");
        if (int.TryParse(Console.ReadLine(), out int accountIndex) &&
            accountIndex >= 1 && accountIndex <= accounts.Count)
        {
            BankAccount selectedAccount = accounts[accountIndex - 1];
            ManageAccount(selectedAccount);
        }
        else
        {
            Console.WriteLine("Некорректный выбор счета.");
        }
    }

    static void ManageAccount(BankAccount account)
    {
        int action;
        do
        {
            Console.WriteLine("\n--- Управление счетом ---");
            Console.WriteLine($"Текущий баланс: {account.GetBalance()}");
            Console.WriteLine("1. Пополнить счет");
            Console.WriteLine("2. Снять средства");
            Console.WriteLine("3. Назад");
            Console.Write("Выберите действие: ");

            if (!int.TryParse(Console.ReadLine(), out action))
            {
                Console.WriteLine("Некорректный ввод. Попробуйте снова.");
                continue;
            }

            switch (action)
            {
                case 1:
                    Console.Write("Введите сумму для пополнения: ");
                    if (decimal.TryParse(Console.ReadLine(), out decimal depositAmount))
                    {
                        account.Deposit(depositAmount);
                    }
                    else
                    {
                        Console.WriteLine("Некорректная сумма.");
                    }
                    break;
                case 2:
                    Console.Write("Введите сумму для снятия: ");
                    if (decimal.TryParse(Console.ReadLine(), out decimal withdrawAmount))
                    {
                        account.Withdraw(withdrawAmount);
                    }
                    else
                    {
                        Console.WriteLine("Некорректная сумма.");
                    }
                    break;
                case 3:
                    Console.WriteLine("Возврат в предыдущее меню...");
                    break;
                default:
                    Console.WriteLine("Неизвестное действие. Попробуйте снова.");
                    break;
            }

        } while (action != 3);
    }
}
