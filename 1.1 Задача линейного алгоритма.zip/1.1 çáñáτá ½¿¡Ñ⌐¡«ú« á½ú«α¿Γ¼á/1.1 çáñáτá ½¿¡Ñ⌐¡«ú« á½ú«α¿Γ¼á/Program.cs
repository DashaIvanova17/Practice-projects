﻿using System;

class AcidSolutionCalculator
{
    static void Main()
    {
        double v1 = 10.0;        // объем первого раствора
        double c1 = 0.05;        // концентрация первого раствора
        double c2 = 0.20;        // концентрация второго раствора
        double cFinal = 0.12;    // желаемая концентрация конечного раствора

        double x = (v1 * (c1 - cFinal)) / (cFinal - c2);

        Console.WriteLine($"Необходимо добавить {x:F2} литров 20%-го раствора.");
        Console.ReadKey();
    }
}
