﻿using System;

class NumberTriangle
{
    static void Main()
    {
        try
        {
            Console.WriteLine("Программа вывода треугольника из чисел");
            Console.Write("Введите высоту треугольника (целое число больше 0): ");

            // Чтение ввода и преобразование в число
            int height = int.Parse(Console.ReadLine());

            // Проверка на корректность ввода
            if (height <= 0)
            {
                throw new ArgumentException("Высота треугольника должна быть положительным числом!");
            }

            Console.WriteLine("\nРезультат:");

            // Построение треугольника
            for (int i = 1; i <= height; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j + " ");
                }
                Console.WriteLine();
            }
        }
        catch (FormatException ex)
        {
            Console.WriteLine("\nОшибка: Введено не числовое значение!");
            Console.WriteLine($"Подробности: {ex.Message}");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine("\nОшибка: " + ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine("\nПроизошла непредвиденная ошибка!");
            Console.WriteLine($"Тип ошибки: {ex.GetType()}");
            Console.WriteLine($"Сообщение: {ex.Message}");
        }
        finally
        {
            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}
