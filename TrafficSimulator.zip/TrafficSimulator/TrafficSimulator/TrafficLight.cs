﻿using System.Drawing;
using System.Windows.Forms;

namespace TrafficSimulator
{
    public class TrafficLight
    {
        public LightState State { get; set; }
        public Point Location { get; set; }
        private Timer timer;
        private int counter = 0;

        public TrafficLight(Point location)
        {
            Location = location;
            State = LightState.Red;

            timer = new Timer();
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, System.EventArgs e)
        {
            counter++;
            if (counter >= 10) // Меняем состояние каждые 10 секунд
            {
                ChangeState();
                counter = 0;
            }
        }

        public void ChangeState()
        {
            switch (State)
            {
                case LightState.Red:
                    State = LightState.Green;
                    break;
                case LightState.Green:
                    State = LightState.Yellow;
                    break;
                case LightState.Yellow:
                    State = LightState.Red;
                    break;
            }
        }

        public void Draw(Graphics g)
        {
            // Корпус светофора
            g.FillRectangle(Brushes.Black, Location.X - 15, Location.Y, 30, 80);

            // Сигналы
            g.FillEllipse(State == LightState.Red ? Brushes.Red : Brushes.DarkRed,
                Location.X - 10, Location.Y + 10, 20, 20);
            g.FillEllipse(State == LightState.Yellow ? Brushes.Yellow : Brushes.DarkGoldenrod,
                Location.X - 10, Location.Y + 30, 20, 20);
            g.FillEllipse(State == LightState.Green ? Brushes.Green : Brushes.DarkGreen,
                Location.X - 10, Location.Y + 50, 20, 20);
        }
    }
}
