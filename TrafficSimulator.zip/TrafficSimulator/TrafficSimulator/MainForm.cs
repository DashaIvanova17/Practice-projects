﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace TrafficSimulator
{
    public partial class MainForm : Form
    {
        private List<Vehicle> vehicles = new List<Vehicle>();
        private List<TrafficLight> trafficLights = new List<TrafficLight>();
        private Random random = new Random();
        private Timer spawnTimer;
        private Timer gameTimer;
        private Bitmap buffer;
        private Graphics bufferGraphics;
        private int roadWidth = 600;
        private int roadY = 200;

        public MainForm()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.ClientSize = new Size(800, 500);
            this.Text = "Traffic Simulator";

            // Инициализация буфера для рисования
            buffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
            bufferGraphics = Graphics.FromImage(buffer);

            // Создаем светофоры
            trafficLights.Add(new TrafficLight(new Point(300, roadY - 50)));
            trafficLights.Add(new TrafficLight(new Point(500, roadY - 50)));

            // Таймер для создания новых автомобилей
            spawnTimer = new Timer();
            spawnTimer.Interval = 2000;
            spawnTimer.Tick += SpawnTimer_Tick;
            spawnTimer.Start();

            // Таймер для обновления игры
            gameTimer = new Timer();
            gameTimer.Interval = 50; // 20 FPS
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();

            // Добавляем кнопки управления
            AddControls();
        }

        private void AddControls()
        {
            var btnAddCar = new Button
            {
                Text = "Добавить автомобиль",
                Location = new Point(10, 10),
                Size = new Size(150, 30)
            };
            btnAddCar.Click += BtnAddCar_Click;
            this.Controls.Add(btnAddCar);

            var btnToggleLights = new Button
            {
                Text = "Переключить светофоры",
                Location = new Point(170, 10),
                Size = new Size(150, 30)
            };
            btnToggleLights.Click += BtnToggleLights_Click;
            this.Controls.Add(btnToggleLights);
        }

        private void BtnToggleLights_Click(object sender, EventArgs e)
        {
            foreach (var light in trafficLights)
            {
                light.ChangeState();
            }
        }

        private void BtnAddCar_Click(object sender, EventArgs e)
        {
            AddRandomCar();
        }

        private void SpawnTimer_Tick(object sender, EventArgs e)
        {
            if (random.Next(0, 100) < 30) // 30% вероятность
            {
                AddRandomCar();
            }
        }

        private void AddRandomCar()
        {
            var direction = random.Next(0, 2) == 0 ? Direction.LeftToRight : Direction.RightToLeft;
            int startX = direction == Direction.LeftToRight ? -50 : roadWidth + 50;

            var car = new Car
            {
                Color = Color.FromArgb(random.Next(100, 256), random.Next(100, 256), random.Next(100, 256)),
                Speed = random.Next(2, 6),
                Location = new Point(startX, roadY),
                Direction = direction,
                Model = "Car" + vehicles.Count
            };

            vehicles.Add(car);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            // Обновляем позиции
            foreach (var vehicle in vehicles)
            {
                vehicle.Move();
            }

            // Удаляем автомобили за пределами экрана
            vehicles.RemoveAll(v =>
                (v.Direction == Direction.LeftToRight && v.Location.X > roadWidth + 100) ||
                (v.Direction == Direction.RightToLeft && v.Location.X < -100));

            this.Invalidate();
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            // Код инициализации при загрузке формы
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Очищаем буфер
            bufferGraphics.Clear(Color.LightGray);

            // Рисуем дорогу
            bufferGraphics.FillRectangle(Brushes.DarkGray, 0, roadY, roadWidth, 100);
            bufferGraphics.DrawLine(Pens.White, 0, roadY + 50, roadWidth, roadY + 50);

            // Рисуем светофоры
            foreach (var light in trafficLights)
            {
                light.Draw(bufferGraphics);
            }

            // Рисуем автомобили
            foreach (var vehicle in vehicles)
            {
                vehicle.Draw(bufferGraphics);
            }

            // Статистика
            bufferGraphics.DrawString($"Автомобилей: {vehicles.Count}",
                new Font("Arial", 12), Brushes.Black, 10, 50);

            e.Graphics.DrawImage(buffer, 0, 0);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (buffer != null)
            {
                buffer.Dispose();
                bufferGraphics.Dispose();
                buffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
                bufferGraphics = Graphics.FromImage(buffer);
            }
        }
    }
}