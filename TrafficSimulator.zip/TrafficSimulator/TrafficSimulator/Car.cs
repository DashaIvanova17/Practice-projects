﻿using System.Drawing;

namespace TrafficSimulator
{
    public class Car : Vehicle
    {
        public string Model { get; set; }

        public override void Draw(Graphics g)
        {
            // Кузов автомобиля
            g.FillRectangle(new SolidBrush(Color), Location.X, Location.Y, Size, Size / 2);

            // Окна
            g.FillRectangle(Brushes.LightBlue, Location.X + 5, Location.Y + 5, 8, 8);
            g.FillRectangle(Brushes.LightBlue, Location.X + 17, Location.Y + 5, 8, 8);

            // Колеса
            g.FillEllipse(Brushes.Black, Location.X + 3, Location.Y + 15, 8, 8);
            g.FillEllipse(Brushes.Black, Location.X + 19, Location.Y + 15, 8, 8);
        }
    }
}
