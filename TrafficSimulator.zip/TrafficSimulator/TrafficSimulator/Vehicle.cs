﻿using System.Drawing;

namespace TrafficSimulator
{
    public abstract class Vehicle
    {
        public Color Color { get; set; }
        public int Speed { get; set; }
        public Point Location { get; set; }
        public Direction Direction { get; set; }
        public int Size { get; set; } = 30;

        public abstract void Draw(Graphics g);

        public void Move()
        {
            if (Direction == Direction.LeftToRight)
            {
                Location = new Point(Location.X + Speed, Location.Y);
            }
            else
            {
                Location = new Point(Location.X - Speed, Location.Y);
            }
        }
    }
}