﻿using System;

class PalindromeChecker
{
    static void Main()
    {
        Console.WriteLine("Проверка строки на палиндром");
        Console.Write("Введите строку: ");
        string inputString = Console.ReadLine();

        // Очищаем строку: удаляем пробелы и приводим к нижнему регистру
        string cleanedString = inputString.Replace(" ", "").ToLower();

        bool isPalindrome = true;

        // Проверяем символы с начала и конца строки
        for (int i = 0; i < cleanedString.Length / 2; i++)
        {
            if (cleanedString[i] != cleanedString[cleanedString.Length - 1 - i])
            {
                isPalindrome = false;
                break;
            }
        }

        // Выводим результат
        if (isPalindrome)
        {
            Console.WriteLine($"Строка \"{inputString}\" является палиндромом.");
        }
        else
        {
            Console.WriteLine($"Строка \"{inputString}\" не является палиндромом.");
        }
    }
}